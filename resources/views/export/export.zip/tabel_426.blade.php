<table style="table-layout: fixed; width: 100%">
    <tr>
        <th style="font-weight: 100; color: #006fcc; word-wrap: break-word" >
            
        
        @foreach($kab as $a)				
Jumlah Rumah Sakit Umum, Rumah Sakit Khusus, Rumah Sakit/Rumah Bersalin, Puskesmas, Klinik/Balai Kesehatan, Posyandu, dan Polindes di {{ $a->kab }}, {{$year}}
@endforeach	
</th>
<br>
    </tr>
           
                  <tr>
                        
                        <th bgcolor="#5cb85c" style="vertical-align: middle;"> <center>Kabupaten/Kota</center></th>
                       <th bgcolor="#5cb85c" style="vertical-align: middle;"><center>Rumah Sakit Umum</center></th>
                       <th bgcolor="#5cb85c" style="vertical-align: middle;"><center>Rumah Sakit Khusus</center></th>
                       <th bgcolor="#5cb85c" style="vertical-align: middle;"><center>Rumah Sakit Bersalin</center></th>
                       <th bgcolor="#5cb85c" style="vertical-align: middle;"><center>Puskesmas</center></th>
                       <th bgcolor="#5cb85c" style="vertical-align: middle;"><center>Klinik/Balai</center></th>
                       <th bgcolor="#5cb85c" style="vertical-align: middle;"><center>Posyandu</center></th>
                     <th bgcolor="#5cb85c" style="vertical-align: middle;"><center>Polindes</center></th>
                      
                    </tr>
    
                   
          
                   @foreach ($tabel_426 as $member)
                    <tr>
                       
                        <th >{{ $member->kec }}</th>
                        <td> {{ $member->t426a }} </td>
                        <td> {{ $member->t426b }} </td>
                        <td> {{ $member->t426c }} </td>
                        <td> {{ $member->t426d }} </td>
                        <td> {{ $member->t426e }} </td>
                        <td> {{ $member->t426f }} </td>
                        <td> {{ $member->t426g }} </td>
              
                      
                      
                       
                      
                    </tr>
                    @endforeach
                     <tr>
                        
                        <th bgcolor="#5cb85c" style="vertical-align: middle;">Jumlah</th>
                        @foreach ($sum_lk as $member)
                   
                   <td> {{ $member->sum_a }} </td>
                   <td> {{ $member->sum_b }} </td>
                   <td> {{ $member->sum_c }} </td>
                   <td> {{ $member->sum_d }} </td>
                   <td> {{ $member->sum_e }} </td>
                   <td> {{ $member->sum_f }} </td>
                   <td> {{ $member->sum_g }} </td>
              
                    
       
       
                 
                       @endforeach
                 
                       
                   
                      
                    </tr>
                
    </table>